document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        // Validação simples
        if (!email || !password) {
            alert('Por favor, preencha todos os campos');
            return;
        }
        
        // Simulação de login (em um sistema real, seria uma chamada AJAX)
        console.log('Tentativa de login:', { email, password });
        alert('Login realizado com sucesso! Redirecionando...');
        
        // Redirecionamento (simulado)
        setTimeout(() => {
            window.location.href = 'PaginaInicial.html';
        }, 1000);
    });
});