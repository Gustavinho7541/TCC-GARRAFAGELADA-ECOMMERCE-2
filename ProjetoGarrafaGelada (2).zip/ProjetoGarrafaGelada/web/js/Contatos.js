document.addEventListener('DOMContentLoaded', function() {
    const contatoForm = document.getElementById('contatoForm');
    
    contatoForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validação simples
        const nome = document.getElementById('nome').value;
        const email = document.getElementById('email').value;
        
        if (!nome || !email) {
            alert('Por favor, preencha todos os campos obrigatórios');
            return;
        }
        
        // Simulação de envio
        alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
        contatoForm.reset();
    });
});